# Generations of drones for both 2D and 3D

import random

def generate_dronz_2d(n, bound=1000, seed=None):
    if seed is not None:
        random.seed(seed)
    return [(i, random.random()*bound, random.random()*bound) for i in range(n)]

def generate_dronz_3d(n, bound=1000, seed=None):
    if seed is not None:
        random.seed(seed)
    return [(i, random.random()*bound, random.random()*bound, random.random()*bound) for i in range(n)]
