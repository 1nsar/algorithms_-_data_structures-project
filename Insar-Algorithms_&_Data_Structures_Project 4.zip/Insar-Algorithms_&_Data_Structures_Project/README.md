AI1225 – Drone Collision Prevention (A+ code)

This package contains high-quality implementations for the assignment tasks.
Files of interest:
  - src/task1_2d/closest_pair_dc.py   -> Optimal O(n log n) 2D closest-pair (divide & conquer)
  - src/task2_3d/kdtree_3d.py         -> KD-Tree for exact 3D nearest neighbor search
  - src/task3_topk/topk_kdtree.py     -> Top-k pairs using k-NN over KD-Tree (scales when k small)
  - src/task4_dynamic/dynamic_kdtree.py -> Incremental demo using lazy KD-Tree rebuilds

Note: I removed the report folder as requested. You will prepare the report separately.
