# Closest pair of points in 2D using the standard divide & conquer algorithm

import math
from typing import List, Tuple

Point2D = Tuple[int, float, float]

def _dist(a: Point2D, b: Point2D) -> float:  # a function for distance between two points
    return math.hypot(a[1]-b[1], a[2]-b[2])

def _bruteforce(points: List[Point2D]) -> Tuple[Tuple[Point2D,Point2D], float]:
    best = (None, None)
    best_d = float('inf')
    n = len(points)
    for i in range(n):
        for j in range(i+1, n):
            d = _dist(points[i], points[j])
            pair_ids = tuple(sorted((points[i][0], points[j][0])))
            if d < best_d - 1e-12 or (abs(d - best_d) <= 1e-12 and pair_ids < tuple(sorted((best[0][0], best[1][0])) if best[0] else (float('inf'),float('inf')))):
                best = (points[i], points[j])
                best_d = d
    return best, best_d

def _strip_closest(strip: List[Point2D], d: float): # this is a function to find the closest pair of points 
    best = (None, None)
    best_d = d
    n = len(strip)
    for i in range(n):
        j = i+1

        while j < n and (strip[j][2] - strip[i][2]) < best_d:
            dist_ij = _dist(strip[i], strip[j])
            pair_ids = tuple(sorted((strip[i][0], strip[j][0])))
            if dist_ij < best_d - 1e-12 or (abs(dist_ij - best_d) <= 1e-12 and pair_ids < tuple(sorted((best[0][0], best[1][0])) if best[0] else (float('inf'),float('inf')))):
                best = (strip[i], strip[j])
                best_d = dist_ij
            j += 1
    return best, best_d

def _closest_rec(px: List[Point2D], py: List[Point2D]):
    n = len(px)
    if n <= 3:
        return _bruteforce(px)
    mid = n // 2
    Qx = px[:mid]
    Rx = px[mid:]
    mid_x = px[mid][1]
    Qy = []
    Ry = []
    for p in py:
        if p[1] <= mid_x:
            Qy.append(p)
        else:
            Ry.append(p)
    (p1, q1), d1 = _closest_rec(Qx, Qy)
    (p2, q2), d2 = _closest_rec(Rx, Ry)
    if d1 < d2 - 1e-12 or (abs(d1 - d2) <= 1e-12 and tuple(sorted((p1[0], q1[0]))) < tuple(sorted((p2[0], q2[0])))):
        dmin_pair, dmin = (p1, q1), d1
    else:
        dmin_pair, dmin = (p2, q2), d2
    strip = [p for p in py if abs(p[1] - mid_x) < dmin]
    strip_pair, strip_d = _strip_closest(strip, dmin)
    if strip_pair[0] is not None and (strip_d < dmin - 1e-12 or (abs(strip_d - dmin) <= 1e-12 and tuple(sorted((strip_pair[0][0], strip_pair[1][0]))) < tuple(sorted((dmin_pair[0][0], dmin_pair[1][0]))))):
        return strip_pair, strip_d
    return dmin_pair, dmin

def closest_pair_2d(dronz: List[Point2D]): # this is a function to find the closes pair of points in 2D using the divide and conquer algorithm
    if len(dronz) < 2:
        return None, float('inf')
    px = sorted(dronz, key=lambda p: (p[1], p[2], p[0]))
    py = sorted(dronz, key=lambda p: (p[2], p[1], p[0]))
    pair, d = _closest_rec(px, py)

    if pair[0][0] <= pair[1][0]:
        return pair, d
    else:
        return (pair[1], pair[0]), d

if __name__ == '__main__':
    pts = [(0,0.0,0.0),(1,1.0,1.0),(2,2.0,2.0),(3,0.1,0.1)]
    print(closest_pair_2d(pts))
