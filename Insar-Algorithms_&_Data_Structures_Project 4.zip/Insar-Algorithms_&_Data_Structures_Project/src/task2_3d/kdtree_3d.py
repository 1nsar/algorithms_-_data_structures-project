# A KD-Tree for 3D exact nearest neighbor search

import math
from typing import List, Tuple, Optional
Point3D = Tuple[int, float, float, float]

class KDNode:
    __slots__ = ('point','left','right','axis')
    def __init__(self, point: Point3D, axis: int): 
        self.point = point
        self.left = None
        self.right = None
        self.axis = axis

class KDTree3D:
    def __init__(self, points: List[Point3D]):
        self.root = self._build(points, depth=0)

    def _build(self, pts: List[Point3D], depth: int) -> Optional[KDNode]:
        if not pts:
            return None
        axis = depth % 3
        pts.sort(key=lambda p: p[axis+1])  
        mid = len(pts) // 2
        node = KDNode(pts[mid], axis)
        node.left = self._build(pts[:mid], depth+1)
        node.right = self._build(pts[mid+1:], depth+1)
        return node

    def _sqdist(self, a: Point3D, b: Point3D) -> float: # squared distance between two points
        return (a[1]-b[1])**2 + (a[2]-b[2])**2 + (a[3]-b[3])**2

    def nearest(self, query: Point3D, k:int=1) -> List[Tuple[float, Point3D]]: # k-nearest neighbors to query
    
        best = []  
        import heapq
        def search(node: KDNode):
            if node is None:
                return
            node_point = node.point
            if node_point[0] != query[0]: 
                d2 = self._sqdist(query, node_point)
                if len(best) < k:
                    heapq.heappush(best, (-d2, node_point))
                else:
                    if d2 < -best[0][0] or (d2 == -best[0][0] and tuple(sorted((node_point[0], query[0]))) < tuple(sorted((best[0][1][0], query[0])))):
                        heapq.heapreplace(best, (-d2, node_point))
            axis = node.axis
            coord_q = query[axis+1]
            coord_n = node.point[axis+1]
            go_left_first = coord_q <= coord_n
            first = node.left if go_left_first else node.right
            second = node.right if go_left_first else node.left
            search(first)

            if len(best) < k or (coord_q - coord_n)**2 <= -best[0][0]:
                search(second)
        search(self.root)
        return [(math.sqrt(-negd), pt) for (negd, pt) in sorted(best, reverse=True)]

def closest_pair_3d(points: List[Point3D]): # this is a function to find the closest pair of points in 3D using a KD-Tree
    if len(points) < 2:
        return None, float('inf')
    tree = KDTree3D(points)
    best = None
    best_d = float('inf')
    for p in points:
        neighs = tree.nearest(p, k=2)  
        for dist, q in neighs:
            if q[0] == p[0]:
                continue
            if dist < best_d - 1e-12 or (abs(dist - best_d) <= 1e-12 and tuple(sorted((p[0], q[0]))) < tuple(sorted((best[0][0], best[1][0]))) if best else True):
                best = (p, q)
                best_d = dist
    if best[0][0] <= best[1][0]:
        return best, best_d
    else:
        return (best[1], best[0]), best_d

if __name__ == '__main__':
    pts = [(0,0,0,0),(1,1,1,1),(2,0.1,0.1,0.1)]
    print(closest_pair_3d(pts))
