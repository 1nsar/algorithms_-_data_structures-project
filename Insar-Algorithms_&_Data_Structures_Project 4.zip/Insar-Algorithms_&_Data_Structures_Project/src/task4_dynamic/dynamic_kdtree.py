# Dynamic structure for non static drones 

from typing import List, Tuple, Dict, Optional
import random

from src.task2_3d.kdtree_3d import KDTree3D
from src.task3_topk.topk_kdtree import top_k_pairs

Point3D = Tuple[int, float, float, float]


class DynamicDronz3D: 
    def __init__(self, points: List[Point3D], rebuild_threshold: int = 50):
        self.points: List[Point3D] = list(points)
        self.rebuild_threshold = rebuild_threshold

        self._index: Dict[int, int] = {p[0]: i for i, p in enumerate(self.points)}

        self._dirty = 0
        self._tree: Optional[KDTree3D] = KDTree3D(self.points)

    def update_point(self, id: int, new_coords: Tuple[float, float, float]): # update the coordinates of a point with a given id
        if id not in self._index:
            return
        idx = self._index[id]
        self.points[idx] = (id, float(new_coords[0]), float(new_coords[1]), float(new_coords[2]))
        self._dirty += 1

        if self._dirty >= self.rebuild_threshold:
            self.rebuild()

    def rebuild(self):
        self._tree = KDTree3D(self.points)
        self._dirty = 0

    def _ensure_fresh_tree_for_query(self): 
        if self._dirty > 0:
            self.rebuild()

    def batch_random_walk(self, fraction: float = 0.01, step: float = 1.0, seed=None): # simulation of movement of drones 
        if seed is not None:
            random.seed(seed)

        n = len(self.points)
        if n == 0:
            return
        m = max(1, int(n * fraction))
        ids = random.sample(list(self._index.keys()), m)

        for idd in ids:
            idx = self._index[idd]
            p = self.points[idx]
            new = [c + random.uniform(-step, step) for c in p[1:]]
            self.update_point(idd, (new[0], new[1], new[2]))

    def current_topk(self, k: int): # current top k closest pairs of points
        self._ensure_fresh_tree_for_query()
        return top_k_pairs(self.points, k, method="optimized")

    def current_closest(self): # current closest pair of points
        res = self.current_topk(1)
        if not res:
            return None, float("inf")
        d, pair = res[0]
        return pair, d


if __name__ == "__main__":
    pts = [(i, float(i), float(i), float(i)) for i in range(100)]
    dyn = DynamicDronz3D(pts, rebuild_threshold=10)
    dyn.update_point(3, (0.05, 0.05, 0.05))
    print(dyn.current_closest())
    print(dyn.current_topk(5))