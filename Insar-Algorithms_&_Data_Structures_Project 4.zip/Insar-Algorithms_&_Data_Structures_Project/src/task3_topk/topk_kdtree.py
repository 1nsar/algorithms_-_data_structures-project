import math
import heapq
from typing import List, Tuple, Set, Optional

from src.task2_3d.kdtree_3d import KDTree3D

Point3D = Tuple[int, float, float, float]
PairOut = Tuple[float, Tuple[Point3D, Point3D]]

_EPS = 1e-12


def _pair_key(a: Point3D, b: Point3D) -> Tuple[int, int]:
    ia, ib = a[0], b[0]
    return (ia, ib) if ia <= ib else (ib, ia)


def baseline_topk_allpairs(points: List[Point3D], k: int) -> List[PairOut]: # this is a baseline function to find the top k closest pairs of points 
    if k <= 0 or len(points) < 2:
        return []

    candidates: List[PairOut] = []
    n = len(points)
    for i in range(n):
        pi = points[i]
        for j in range(i + 1, n):
            pj = points[j]
            dx = pi[1] - pj[1]
            dy = pi[2] - pj[2]
            dz = pi[3] - pj[3]
            d = math.sqrt(dx * dx + dy * dy + dz * dz)

            if pi[0] <= pj[0]:
                candidates.append((d, (pi, pj)))
            else:
                candidates.append((d, (pj, pi)))

    return heapq.nsmallest(k, candidates, key=lambda x: (x[0], x[1][0][0], x[1][1][0]))


def optimized_topk_candidates(points: List[Point3D], k: int, neighbor_k: Optional[int] = None) -> List[PairOut]: # this is an optimized function to find the top k closest pairs of points using a KD-Tree
    if k <= 0 or len(points) < 2:
        return []

    if neighbor_k is None:
        neighbor_k = max(k + 1, 32)

    tree = KDTree3D(points)

    candidates: List[PairOut] = []
    seen: Set[Tuple[int, int]] = set()

    for p in points:
        neighs = tree.nearest(p, k=neighbor_k + 1)
        for dist, q in neighs:
            if q[0] == p[0]:
                continue
            key = _pair_key(p, q)
            if key in seen:
                continue
            seen.add(key)
            if p[0] <= q[0]:
                candidates.append((dist, (p, q)))
            else:
                candidates.append((dist, (q, p)))

    return heapq.nsmallest(k, candidates, key=lambda x: (x[0], x[1][0][0], x[1][1][0]))


def top_k_pairs( # finding the top k closest pairs
    points: List[Point3D],
    k: int,
    *,
    method: str = "auto",
    exact_threshold: int = 2000,
    neighbor_k: Optional[int] = None,
    validate_on_small: bool = False,
) -> List[PairOut]:

    n = len(points)

    if method not in {"auto", "exact", "optimized"}:
        raise ValueError("method must be one of: auto, exact, optimized")

    if method == "auto":
        use_exact = n <= exact_threshold
    else:
        use_exact = (method == "exact")

    if use_exact:
        exact = baseline_topk_allpairs(points, k)
        if validate_on_small:
            approx = optimized_topk_candidates(points, k, neighbor_k=neighbor_k)
            if exact != approx:
                raise AssertionError("Validation failed: optimized output != baseline output for this dataset.")
        return exact

    return optimized_topk_candidates(points, k, neighbor_k=neighbor_k)


if __name__ == "__main__":
    pts = [(0, 0, 0, 0), (1, 1, 1, 1), (2, 0.1, 0.1, 0.1), (3, 10, 10, 10)]
    print("Exact:", top_k_pairs(pts, 3, method="exact"))
    print("Opt  :", top_k_pairs(pts, 3, method="optimized"))